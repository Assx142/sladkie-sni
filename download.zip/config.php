<?php
declare(strict_types=1);
session_start();

/*
 * ВПИШИТЕ СЮДА данные из InfinityFree -> MySQL Databases.
 * Не публикуйте этот файл в открытом GitHub-репозитории.
 */
const DB_HOST = 'sql306.infinityfree.com';
const DB_NAME = ' if0_43459498_dsfsdf';
const DB_USER = 'if0_43459498';
const DB_PASS = 'P0zneWbQslQFb';

const ADMIN_LOGIN = 'hotel123';
const ADMIN_PASSWORD = 'adminHotel';

function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $dsn = 'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4';
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    return $pdo;
}
function e($value): string { return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function check_csrf(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $token = $_POST['csrf'] ?? '';
        if (!is_string($token) || !hash_equals(csrf_token(), $token)) {
            http_response_code(400); exit('Ошибка проверки формы. Обновите страницу и попробуйте снова.');
        }
    }
}
function require_admin(): void {
    if (empty($_SESSION['admin'])) { header('Location: login.php'); exit; }
}
function status_label(string $s): string {
    return ['pending'=>'На рассмотрении','approved'=>'Одобрена','rejected'=>'Отклонена'][$s] ?? $s;
}
